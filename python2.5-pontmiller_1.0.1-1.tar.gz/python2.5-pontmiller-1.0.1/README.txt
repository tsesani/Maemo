README for the Open Clip Art Library
------------------------------------

This is a collection of 100% license-free, royalty-free, and
restriction-free art that you can use for any purpose.

The goal of the Open Clip Art Library is to provide the public with a
huge collection of reusable art.

For more information, including how you can contribute to this growing
library, please see http://www.openclipart.org/.

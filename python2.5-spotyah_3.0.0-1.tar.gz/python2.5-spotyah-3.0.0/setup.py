from distutils.core import setup

setup(name='spotyah', 
    version='3.0.0', 
    scripts=['spotyah'], 
    data_files = [('share/pixmaps', ['spotyah.png']), 
    ('share/applications/hildon', ['spotyah.desktop']), 
    ('share/dbus-1/services', ['spotyah.service']),])
    
